@echo off
echo ========================================
echo Phishing Analyzer - Build Executable
echo ========================================
echo.

REM Check if Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python is not installed or not in PATH
    echo Please install Python from https://www.python.org/downloads/
    pause
    exit /b 1
)

echo [1/4] Installing dependencies...
pip install -r requirements.txt --quiet
if errorlevel 1 (
    echo ERROR: Failed to install dependencies
    pause
    exit /b 1
)

echo [2/4] Installing PyInstaller...
pip install pyinstaller --quiet
if errorlevel 1 (
    echo ERROR: Failed to install PyInstaller
    pause
    exit /b 1
)

echo [3/4] Building executable (this may take 2-3 minutes)...
pyinstaller --onefile --windowed --name=PhishingAnalyzer --add-data="src;src" --version-file=version.txt main.py 2>nul
if not exist version.txt (
    pyinstaller --onefile --windowed --name=PhishingAnalyzer --add-data="src;src" main.py
) else (
    pyinstaller --onefile --windowed --name=PhishingAnalyzer --add-data="src;src" --version-file=version.txt main.py
)
if errorlevel 1 (
    echo ERROR: Build failed
    pause
    exit /b 1
)

echo [4/4] Cleaning up build files...
rmdir /s /q build >nul 2>&1
del /q PhishingAnalyzer.spec >nul 2>&1

echo.
echo ========================================
echo BUILD SUCCESSFUL!
echo ========================================
echo.
echo Your executable is ready at:
echo   dist\PhishingAnalyzer.exe
echo.
echo File size: ~50MB
echo.
echo You can now:
echo   1. Run dist\PhishingAnalyzer.exe to test
echo   2. Share PhishingAnalyzer.exe (no Python needed)
echo   3. Upload to GitHub releases
echo.
pause
