# 🛡️ Phishing Email Analyzer

A desktop cybersecurity tool for analyzing suspicious emails and detecting phishing indicators.

## 📋 Features

- **Email Parsing**: Load `.eml` files or paste raw email text
- **Header Analysis**: Detect SPF/DKIM issues, sender mismatches, suspicious routing
- **URL Detection**: Identify malicious links, typosquatting, shorteners, IP addresses
- **Content Analysis**: Regex-based detection of urgency tactics, threats, credential requests
- **Risk Scoring**: 0-100 risk score with detailed explanations
- **Security Tips**: Actionable recommendations based on detected threats

## 🏗️ Architecture

```
phishing-analyzer/
├── src/
│   ├── core/              # Analysis modules
│   │   ├── email_parser.py       # Parse .eml and raw email
│   │   ├── header_analyzer.py    # Analyze email headers
│   │   ├── url_extractor.py      # Extract and analyze URLs
│   │   ├── content_analyzer.py   # Regex-based content analysis
│   │   └── risk_scorer.py        # Aggregate risk scoring
│   ├── ui/
│   │   └── main_window.py        # PySide6 UI
│   └── utils/
│       └── config.py              # Configuration & patterns
├── main.py                # Application entry point
└── requirements.txt       # Dependencies
```

## 🚀 Installation

### Prerequisites
- Python 3.8 or higher
- pip package manager

### Setup

1. **Install dependencies**:
```bash
pip install -r requirements.txt
```

2. **Run the application**:
```bash
python main.py
```

## 🔧 Usage

### Method 1: Load .EML File
1. Click "Load .EML File"
2. Select an email file
3. Click "Analyze Email"

### Method 2: Paste Raw Email
1. Click "Paste Raw Email"
2. Paste email headers and body
3. Click "Analyze Email"

### Understanding Results

**Risk Levels**:
- **Low (0-30)**: Minimal phishing indicators
- **Medium (31-60)**: Several suspicious characteristics
- **High (61-100)**: Strong phishing indicators

**Score Breakdown**:
- Header Analysis: 0-25 points
- URL Analysis: 0-30 points
- Content Analysis: 0-25 points
- Urgency/Social Engineering: 0-20 points

## 📦 Building Executable

To create a standalone `.exe` file:

```bash
pyinstaller --onefile --windowed --name PhishingAnalyzer main.py
```

The executable will be in the `dist/` folder.

### Build Options Explained:
- `--onefile`: Single executable file
- `--windowed`: No console window (GUI only)
- `--name`: Custom application name

## 🧪 Testing

### Sample Phishing Indicators to Test:

**Header Issues**:
- Mismatched sender names ("PayPal" from gmail.com)
- Missing SPF/DKIM authentication
- Different Reply-To address

**URL Indicators**:
- IP addresses instead of domains
- Suspicious TLDs (.xyz, .top, .click)
- URL shorteners
- Typosquatting (paypa1.com)

**Content Patterns**:
- Urgency keywords ("urgent", "immediate action")
- Credential requests ("verify password")
- Threats ("account will be suspended")
- Generic greetings ("Dear Customer")

## 🔒 Security Features

### Detection Capabilities

1. **Authentication Analysis**
   - SPF record validation
   - DKIM signature verification
   - Return-Path consistency

2. **URL Analysis**
   - Typosquatting detection
   - Suspicious TLD identification
   - Link/display text mismatch
   - IP address usage

3. **Content Analysis**
   - Urgency/pressure tactics
   - Credential phishing patterns
   - Financial information requests
   - Threatening language

4. **Pattern Matching**
   - 30+ phishing regex patterns
   - Known malicious TLDs
   - Free email provider detection

## 🎯 Use Cases

- **Security Awareness Training**: Demonstrate phishing techniques
- **Email Triage**: Quick assessment of suspicious emails
- **Incident Response**: Initial analysis of reported phishing
- **Portfolio Project**: Showcase cybersecurity & development skills

## 💡 How It Works

1. **Parsing**: Email is parsed using Python's `email` library
2. **Analysis**: Four parallel analysis modules score different aspects
3. **Scoring**: Weighted risk calculation (max 100 points)
4. **Reporting**: Human-readable explanations and recommendations

## 🛠️ Technology Stack

- **Language**: Python 3.8+
- **GUI Framework**: PySide6 (Qt for Python)
- **Email Parsing**: Built-in `email` library
- **Pattern Matching**: Regular expressions
- **Packaging**: PyInstaller

## 📝 Configuration

Edit `src/utils/config.py` to customize:
- Risk score thresholds
- Phishing patterns
- Suspicious TLDs
- URL shortener list

## ⚠️ Limitations

- **No API Dependencies**: Runs entirely offline (no VirusTotal, etc.)
- **Regex-Based**: May have false positives/negatives
- **Static Analysis**: Cannot sandbox attachments or execute code
- **English-Focused**: Patterns optimized for English emails

## 🚧 Future Enhancements

- [ ] Attachment analysis
- [ ] Machine learning classification
- [ ] VirusTotal integration
- [ ] Database of known phishing campaigns
- [ ] Multi-language support
- [ ] Batch analysis mode

## 📚 Learning Resources

This tool demonstrates:
- **Modular Python architecture**
- **Desktop GUI development (Qt)**
- **Email protocol understanding**
- **Cybersecurity analysis techniques**
- **Regular expression pattern matching**
- **Threat scoring methodologies**

## 🤝 Contributing

This is a portfolio project, but suggestions are welcome!

## 📄 License

MIT License - Free for educational and portfolio use

## 👨‍💻 Author

**ABDULLAHI ISSACK MOHAMED**

Created as a cybersecurity portfolio project to demonstrate:
- Security analysis capabilities
- Software engineering best practices
- Clean, modular code design
- User-focused interface design

---

**Disclaimer**: This tool is for educational and defensive security purposes only. 
It should complement, not replace, professional security solutions.
