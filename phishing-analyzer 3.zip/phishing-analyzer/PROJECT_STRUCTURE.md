# 📁 Project Structure

```
phishing-analyzer/
│
├── 📄 main.py                          # Application entry point
├── 📄 build.py                         # Build script for .exe
├── 📄 requirements.txt                 # Python dependencies
├── 📄 README.md                        # Full documentation
├── 📄 QUICKSTART.md                    # Quick start guide
├── 📄 .gitignore                       # Git ignore rules
│
├── 📂 src/                             # Source code
│   │
│   ├── 📂 core/                        # Core analysis modules
│   │   ├── __init__.py
│   │   ├── 📄 email_parser.py         # Parse .eml files & raw text
│   │   ├── 📄 header_analyzer.py      # Analyze email headers
│   │   ├── 📄 url_extractor.py        # Extract & analyze URLs
│   │   ├── 📄 content_analyzer.py     # Content pattern matching
│   │   └── 📄 risk_scorer.py          # Risk calculation & reporting
│   │
│   ├── 📂 ui/                          # User interface
│   │   ├── __init__.py
│   │   └── 📄 main_window.py          # PySide6 main window
│   │
│   └── 📂 utils/                       # Utilities & config
│       ├── __init__.py
│       └── 📄 config.py               # Patterns & constants
│
├── 📂 sample_emails/                   # Test email samples
│   ├── 📄 sample_phishing.eml         # High-risk phishing example
│   └── 📄 sample_legitimate.eml       # Low-risk legitimate example
│
└── 📂 tests/                           # Unit tests (future)
    └── (empty - ready for expansion)
```

## 🔍 Module Descriptions

### Core Modules

#### `email_parser.py`
- **Purpose**: Parse email files and raw text
- **Key Functions**:
  - `parse_eml_file()` - Load and parse .eml files
  - `parse_raw_email()` - Parse pasted email text
  - `get_from_email()` - Extract sender email
  - `get_from_name()` - Extract sender display name
- **Dependencies**: Python `email` library
- **Output**: Structured dictionary with headers, body, HTML

#### `header_analyzer.py`
- **Purpose**: Analyze email headers for authentication & routing issues
- **Detection Methods**:
  - SPF/DKIM authentication checks
  - Sender/Return-Path mismatch
  - Reply-To discrepancies
  - Suspicious routing patterns
  - Free email provider detection
- **Risk Score**: Up to 25 points
- **Output**: Findings list + risk score

#### `url_extractor.py`
- **Purpose**: Extract and analyze URLs from email body
- **Detection Methods**:
  - IP address usage instead of domains
  - Suspicious TLDs (.xyz, .top, etc.)
  - URL shorteners
  - Typosquatting detection
  - Link/display text mismatch
  - Excessive subdomains
- **Risk Score**: Up to 30 points
- **Output**: URL list + findings + risk score

#### `content_analyzer.py`
- **Purpose**: Pattern-based content analysis
- **Detection Categories**:
  - **Urgency**: "act now", "expires today", "immediate action"
  - **Financial**: "bank account", "credit card", "wire transfer"
  - **Credentials**: "verify password", "update account"
  - **Threats**: "account suspended", "legal action"
- **Additional Checks**:
  - Generic greetings
  - Spelling/grammar issues
  - Excessive punctuation/caps
- **Risk Score**: Up to 25 points
- **Pattern Count**: 30+ regex patterns

#### `risk_scorer.py`
- **Purpose**: Aggregate scores and generate reports
- **Risk Levels**:
  - Low: 0-30 points
  - Medium: 31-60 points
  - High: 61-100 points
- **Output**:
  - Total risk score
  - Breakdown by category
  - Human-readable explanation
  - Actionable recommendations

### UI Module

#### `main_window.py`
- **Framework**: PySide6 (Qt for Python)
- **Features**:
  - File browser for .eml files
  - Paste mode for raw email text
  - Multi-threaded analysis (non-blocking UI)
  - Color-coded risk display
  - Tabbed results view
  - Professional styling
- **Components**:
  - Input section
  - Progress indicator
  - Risk score display
  - Results tabs (Summary, Findings, Recommendations, Details)

### Configuration

#### `config.py`
- **Purpose**: Centralized configuration
- **Contains**:
  - Risk scoring thresholds
  - Phishing pattern regex
  - Suspicious TLDs list
  - URL shortener list
  - Free email provider list
  - Suspicious keyword lists
- **Customization**: Edit to add new patterns

## 🔧 Technology Stack

| Component | Technology | Purpose |
|-----------|-----------|---------|
| Language | Python 3.8+ | Main programming language |
| GUI | PySide6 | Desktop application framework |
| Email Parsing | `email` library | Built-in Python email parser |
| Pattern Matching | Regular Expressions | Phishing pattern detection |
| Threading | QThread | Non-blocking UI during analysis |
| Packaging | PyInstaller | Create standalone executable |

## 🎯 Data Flow

```
1. User Input (File or Paste)
   ↓
2. EmailParser → Parse email structure
   ↓
3. Parallel Analysis:
   ├── HeaderAnalyzer → Check authentication, routing
   ├── URLExtractor → Find and analyze links
   └── ContentAnalyzer → Pattern matching
   ↓
4. RiskScorer → Aggregate results
   ↓
5. UI Display → Show color-coded results
```

## 📊 Scoring System

| Category | Max Points | Key Indicators |
|----------|-----------|----------------|
| Headers | 25 | SPF/DKIM, sender mismatch, routing |
| URLs | 30 | IP addresses, typosquatting, shorteners |
| Content | 25 | Urgency, threats, credential requests |
| Social Engineering | 20 | Generic greetings, pressure tactics |
| **Total** | **100** | - |

## 🚀 Execution Modes

### Development Mode
```bash
python main.py
```
- Runs from source code
- Requires Python + dependencies
- Hot-reload friendly for development

### Production Mode (Executable)
```bash
pyinstaller --onefile --windowed --name PhishingAnalyzer main.py
```
- Creates standalone .exe
- No Python installation needed
- ~50MB file size (includes Python runtime)
- Located in `dist/` folder

## 📝 Code Quality Features

- ✅ **Modular Design**: Each component is independent
- ✅ **Type Hints**: Enhanced code readability
- ✅ **Docstrings**: Comprehensive documentation
- ✅ **Error Handling**: Try-except blocks for robustness
- ✅ **Clean Code**: PEP 8 compliance
- ✅ **Separation of Concerns**: UI, logic, config separated
- ✅ **Extensibility**: Easy to add new detection patterns

## 🔐 Security Considerations

### Runs Offline
- No external API calls
- No data transmission
- Complete privacy

### Safe Analysis
- Only parses email metadata and text
- Does NOT execute code
- Does NOT open attachments
- Read-only operations

### Limitations
- Cannot detect zero-day techniques
- May have false positives on legitimate emails
- Pattern-based (not AI/ML)
- English-language focused

## 🎓 Learning Outcomes

This project demonstrates proficiency in:

1. **Python Development**
   - Object-oriented programming
   - Module organization
   - Package management

2. **GUI Development**
   - Desktop application design
   - Event-driven programming
   - User experience considerations

3. **Cybersecurity**
   - Email protocol understanding
   - Threat detection methodologies
   - Security analysis techniques

4. **Software Engineering**
   - Modular architecture
   - Code documentation
   - Build and deployment

---

**Perfect for portfolio showcasing**: Clean code, professional UI, real-world application!
