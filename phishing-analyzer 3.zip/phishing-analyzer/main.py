"""
Phishing Analysis Tool
Main application entry point
"""

import sys
from PySide6.QtWidgets import QApplication
from src.ui.main_window import MainWindow


def main():
    """Main application entry point"""
    app = QApplication(sys.argv)
    app.setApplicationName("Phishing Analyzer")
    app.setOrganizationName("ABDULLAHI ISSACK MOHAMED")
    app.setOrganizationDomain("cybersecurity-portfolio")
    
    window = MainWindow()
    window.show()
    
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
