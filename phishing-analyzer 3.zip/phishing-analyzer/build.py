"""
Build script for creating standalone executable
Run this to create PhishingAnalyzer.exe
"""

import os
import sys

def build_exe():
    """Build executable using PyInstaller"""
    
    print("=" * 60)
    print("Phishing Analyzer - Executable Builder")
    print("Developer: ABDULLAHI ISSACK MOHAMED")
    print("=" * 60)
    
    # PyInstaller command
    cmd = [
        "pyinstaller",
        "--onefile",              # Single file
        "--windowed",             # No console (GUI only)
        "--name=PhishingAnalyzer",  # Executable name
        "--add-data=src:src",     # Include source folder
        "--version-file=version.txt",  # Version metadata
        "--icon=NONE",            # No icon (you can add one later)
        "main.py"
    ]
    
    cmd_str = " ".join(cmd)
    print(f"\nRunning: {cmd_str}\n")
    
    result = os.system(cmd_str)
    
    if result == 0:
        print("\n" + "=" * 60)
        print("✅ BUILD SUCCESSFUL!")
        print("=" * 60)
        print("\nExecutable location: dist/PhishingAnalyzer.exe")
        print("\nYou can now:")
        print("1. Run dist/PhishingAnalyzer.exe to test")
        print("2. Share the .exe file (no Python installation needed)")
        print("3. Upload to GitHub releases")
    else:
        print("\n" + "=" * 60)
        print("❌ BUILD FAILED")
        print("=" * 60)
        print("\nMake sure you have PyInstaller installed:")
        print("pip install pyinstaller")
    
    return result

if __name__ == "__main__":
    sys.exit(build_exe())
