"""
Configuration and constants for the Phishing Analyzer
"""

# Risk scoring thresholds
RISK_LOW = 30
RISK_MEDIUM = 60
RISK_HIGH = 100

# Scoring weights
SCORE_HEADER_ANOMALY = 25
SCORE_URL_RISK = 30
SCORE_CONTENT_PATTERN = 25
SCORE_URGENCY = 20

# Suspicious patterns for content analysis
PHISHING_PATTERNS = {
    'urgency': [
        r'urgent(?:ly)?',
        r'immediate(?:ly)?\s+action',
        r'act\s+now',
        r'within\s+\d+\s+hours?',
        r'expire[sd]?\s+(?:today|soon|immediately)',
        r'suspended?\s+account',
        r'verify\s+(?:your\s+)?account',
        r'confirm\s+(?:your\s+)?identity',
    ],
    'financial': [
        r'bank\s+account',
        r'credit\s+card',
        r'ssn|social\s+security',
        r'routing\s+number',
        r'wire\s+transfer',
        r'refund\s+pending',
        r'unusual\s+activity',
        r'unauthorized\s+(?:access|transaction)',
    ],
    'credentials': [
        r'update\s+(?:your\s+)?password',
        r'reset\s+(?:your\s+)?password',
        r'login\s+credentials',
        r'username\s+and\s+password',
        r'click\s+(?:here|below)\s+to\s+(?:verify|confirm|login)',
    ],
    'threats': [
        r'account\s+(?:will\s+be\s+)?(?:suspended|closed|terminated)',
        r'legal\s+action',
        r'failure\s+to\s+(?:comply|respond)',
        r'final\s+(?:warning|notice)',
    ],
}

# Suspicious TLDs
SUSPICIOUS_TLDS = [
    '.xyz', '.top', '.club', '.work', '.click', '.link', '.online',
    '.site', '.website', '.space', '.tech', '.store', '.bid', '.win',
    '.vip', '.loan', '.download', '.racing', '.review', '.trade'
]

# IP address pattern in URLs
IP_PATTERN = r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}'

# URL shorteners
URL_SHORTENERS = [
    'bit.ly', 'tinyurl.com', 'goo.gl', 'ow.ly', 't.co', 'is.gd',
    'buff.ly', 'adf.ly', 'bitly.com', 'short.link', 'rebrand.ly'
]

# Suspicious header indicators
SUSPICIOUS_HEADERS = {
    'mismatched_from': 'Sender email doesn\'t match displayed name',
    'missing_spf': 'Missing SPF authentication',
    'missing_dkim': 'Missing DKIM signature',
    'suspicious_received': 'Suspicious routing path',
    'freemail_sender': 'Sent from free email provider',
}

# Free email providers
FREE_EMAIL_PROVIDERS = [
    'gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com',
    'aol.com', 'mail.com', 'protonmail.com', 'icloud.com'
]
