"""
Main Window UI
PySide6 desktop application interface
"""

from PySide6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                                QPushButton, QTextEdit, QLabel, QFileDialog,
                                QTabWidget, QGroupBox, QProgressBar, QScrollArea)
from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtGui import QFont, QColor, QPalette
import sys
import os

# Add parent directory to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../..'))

from src.core.email_parser import EmailParser
from src.core.header_analyzer import HeaderAnalyzer
from src.core.url_extractor import URLExtractor
from src.core.content_analyzer import ContentAnalyzer
from src.core.risk_scorer import RiskScorer


class AnalysisThread(QThread):
    """Background thread for email analysis"""
    finished = Signal(dict)
    error = Signal(str)
    
    def __init__(self, email_data):
        super().__init__()
        self.email_data = email_data
    
    def run(self):
        try:
            # Initialize analyzers
            parser = EmailParser()
            header_analyzer = HeaderAnalyzer()
            url_extractor = URLExtractor()
            content_analyzer = ContentAnalyzer()
            risk_scorer = RiskScorer()
            
            # Parse email (already done, just use the data)
            headers = self.email_data['headers']
            body = self.email_data['body']
            html_body = self.email_data.get('html_body', '')
            
            # Extract sender info
            from_email = self._extract_email(headers.get('from', ''))
            from_name = self._extract_name(headers.get('from', ''))
            
            # Analyze headers
            header_result = header_analyzer.analyze(headers, from_email, from_name)
            
            # Analyze URLs
            url_result = url_extractor.analyze(body, html_body)
            
            # Analyze content
            content_result = content_analyzer.analyze(
                headers.get('subject', ''), 
                body
            )
            
            # Calculate risk
            risk_result = risk_scorer.calculate_risk(
                header_result, 
                url_result, 
                content_result
            )
            
            # Combine all results
            result = {
                'risk': risk_result,
                'header': header_result,
                'url': url_result,
                'content': content_result,
                'email_info': {
                    'from': headers.get('from', ''),
                    'to': headers.get('to', ''),
                    'subject': headers.get('subject', ''),
                    'date': headers.get('date', ''),
                }
            }
            
            self.finished.emit(result)
            
        except Exception as e:
            self.error.emit(str(e))
    
    def _extract_email(self, from_header):
        """Extract email from From header"""
        import re
        match = re.search(r'<(.+?)>', from_header)
        if match:
            return match.group(1)
        return from_header
    
    def _extract_name(self, from_header):
        """Extract name from From header"""
        import re
        match = re.search(r'^(.+?)\s*<', from_header)
        if match:
            return match.group(1).strip('"').strip("'")
        return ""


class MainWindow(QMainWindow):
    """Main application window"""
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Phishing Analysis Tool")
        self.setMinimumSize(900, 700)
        
        self.parser = EmailParser()
        self.analysis_thread = None
        
        self._init_menu()
        self._init_ui()
        self._apply_styles()
    
    def _init_menu(self):
        """Initialize menu bar"""
        menubar = self.menuBar()
        
        # Help menu
        help_menu = menubar.addMenu("Help")
        
        # About action
        about_action = help_menu.addAction("About")
        about_action.triggered.connect(self.show_about)
    
    def show_about(self):
        """Show About dialog"""
        from PySide6.QtWidgets import QMessageBox
        
        about_text = """
<h2>🛡️ Phishing Email Analyzer</h2>
<p><b>Version:</b> 1.0.0</p>
<p><b>Developer:</b> ABDULLAHI ISSACK MOHAMED</p>
<br>
<p>A professional cybersecurity tool for analyzing suspicious emails and detecting phishing indicators.</p>
<br>
<p><b>Features:</b></p>
<ul>
<li>Email header authentication analysis</li>
<li>Malicious URL detection</li>
<li>Phishing pattern recognition</li>
<li>Risk scoring (0-100)</li>
<li>Security recommendations</li>
</ul>
<br>
<p><b>Technology Stack:</b></p>
<ul>
<li>Python 3.8+</li>
<li>PySide6 (Qt for Python)</li>
<li>Regex-based pattern matching</li>
</ul>
<br>
<p style="color: #666;">© 2024 ABDULLAHI ISSACK MOHAMED<br>Portfolio Project</p>
"""
        
        msg = QMessageBox(self)
        msg.setWindowTitle("About Phishing Analyzer")
        msg.setTextFormat(Qt.RichText)
        msg.setText(about_text)
        msg.setIcon(QMessageBox.Information)
        msg.exec()
    
    def _init_ui(self):
        """Initialize UI components"""
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        main_layout = QVBoxLayout(central_widget)
        main_layout.setSpacing(10)
        
        # Header
        header = QLabel("🛡️ Phishing Email Analyzer")
        header.setFont(QFont("Arial", 18, QFont.Bold))
        header.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(header)
        
        # Developer credit
        developer = QLabel("Developed by ABDULLAHI ISSACK MOHAMED")
        developer.setFont(QFont("Arial", 10))
        developer.setAlignment(Qt.AlignCenter)
        developer.setStyleSheet("color: #2196F3; font-weight: bold; margin-bottom: 10px;")
        main_layout.addWidget(developer)
        
        # Input section
        input_group = QGroupBox("Email Input")
        input_layout = QVBoxLayout()
        
        # Buttons
        button_layout = QHBoxLayout()
        self.load_eml_btn = QPushButton("📁 Load .EML File")
        self.load_eml_btn.clicked.connect(self.load_eml_file)
        
        self.paste_btn = QPushButton("📋 Paste Raw Email")
        self.paste_btn.clicked.connect(self.enable_paste_mode)
        
        self.clear_btn = QPushButton("🗑️ Clear")
        self.clear_btn.clicked.connect(self.clear_all)
        
        button_layout.addWidget(self.load_eml_btn)
        button_layout.addWidget(self.paste_btn)
        button_layout.addWidget(self.clear_btn)
        input_layout.addLayout(button_layout)
        
        # Text input (for paste mode)
        self.email_input = QTextEdit()
        self.email_input.setPlaceholderText("Paste raw email text here and click 'Analyze Email'")
        self.email_input.setMaximumHeight(150)
        self.email_input.setVisible(False)
        input_layout.addWidget(self.email_input)
        
        # File path label
        self.file_label = QLabel("No file loaded")
        self.file_label.setStyleSheet("color: #666; padding: 5px;")
        input_layout.addWidget(self.file_label)
        
        # Analyze button
        self.analyze_btn = QPushButton("🔍 Analyze Email")
        self.analyze_btn.clicked.connect(self.analyze_email)
        self.analyze_btn.setEnabled(False)
        self.analyze_btn.setMinimumHeight(40)
        input_layout.addWidget(self.analyze_btn)
        
        input_group.setLayout(input_layout)
        main_layout.addWidget(input_group)
        
        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        self.progress_bar.setTextVisible(False)
        main_layout.addWidget(self.progress_bar)
        
        # Results section
        results_group = QGroupBox("Analysis Results")
        results_layout = QVBoxLayout()
        
        # Risk score display
        self.risk_display = QLabel("Risk Score: --")
        self.risk_display.setFont(QFont("Arial", 16, QFont.Bold))
        self.risk_display.setAlignment(Qt.AlignCenter)
        self.risk_display.setMinimumHeight(60)
        results_layout.addWidget(self.risk_display)
        
        # Tabs for detailed results
        self.tabs = QTabWidget()
        
        # Summary tab
        self.summary_text = QTextEdit()
        self.summary_text.setReadOnly(True)
        self.tabs.addTab(self.summary_text, "📊 Summary")
        
        # Findings tab
        self.findings_text = QTextEdit()
        self.findings_text.setReadOnly(True)
        self.tabs.addTab(self.findings_text, "🔍 Findings")
        
        # Recommendations tab
        self.recommendations_text = QTextEdit()
        self.recommendations_text.setReadOnly(True)
        self.tabs.addTab(self.recommendations_text, "💡 Recommendations")
        
        # Details tab
        self.details_text = QTextEdit()
        self.details_text.setReadOnly(True)
        self.tabs.addTab(self.details_text, "📧 Email Details")
        
        results_layout.addWidget(self.tabs)
        results_group.setLayout(results_layout)
        main_layout.addWidget(results_group)
        
        # Footer
        footer = QLabel("© 2024 ABDULLAHI ISSACK MOHAMED | Cybersecurity Portfolio Project")
        footer.setAlignment(Qt.AlignCenter)
        footer.setStyleSheet("color: #888; font-size: 10px; padding: 5px;")
        main_layout.addWidget(footer)
    
    def _apply_styles(self):
        """Apply custom styles"""
        self.setStyleSheet("""
            QMainWindow {
                background-color: #f5f5f5;
            }
            QGroupBox {
                font-weight: bold;
                border: 2px solid #ccc;
                border-radius: 5px;
                margin-top: 10px;
                padding-top: 10px;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px;
            }
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 4px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
            QPushButton:pressed {
                background-color: #3d8b40;
            }
            QPushButton:disabled {
                background-color: #cccccc;
                color: #666666;
            }
            QTextEdit {
                border: 1px solid #ddd;
                border-radius: 4px;
                padding: 5px;
                background-color: white;
            }
            QTabWidget::pane {
                border: 1px solid #ccc;
                border-radius: 4px;
            }
            QTabBar::tab {
                background-color: #e0e0e0;
                padding: 8px 16px;
                border-top-left-radius: 4px;
                border-top-right-radius: 4px;
            }
            QTabBar::tab:selected {
                background-color: white;
                font-weight: bold;
            }
        """)
    
    def load_eml_file(self):
        """Load .eml file"""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Email File",
            "",
            "Email Files (*.eml);;All Files (*)"
        )
        
        if file_path:
            self.file_path = file_path
            self.file_label.setText(f"Loaded: {os.path.basename(file_path)}")
            self.file_label.setStyleSheet("color: #4CAF50; padding: 5px;")
            self.analyze_btn.setEnabled(True)
            self.email_input.setVisible(False)
            self.input_mode = 'file'
    
    def enable_paste_mode(self):
        """Enable paste mode"""
        self.email_input.setVisible(True)
        self.email_input.setFocus()
        self.file_label.setText("Paste mode enabled")
        self.file_label.setStyleSheet("color: #2196F3; padding: 5px;")
        self.analyze_btn.setEnabled(True)
        self.input_mode = 'paste'
    
    def clear_all(self):
        """Clear all inputs and results"""
        self.email_input.clear()
        self.email_input.setVisible(False)
        self.file_label.setText("No file loaded")
        self.file_label.setStyleSheet("color: #666; padding: 5px;")
        self.analyze_btn.setEnabled(False)
        self.risk_display.setText("Risk Score: --")
        self.risk_display.setStyleSheet("")
        self.summary_text.clear()
        self.findings_text.clear()
        self.recommendations_text.clear()
        self.details_text.clear()
        self.file_path = None
    
    def analyze_email(self):
        """Start email analysis"""
        try:
            # Parse email
            if hasattr(self, 'input_mode') and self.input_mode == 'paste':
                raw_email = self.email_input.toPlainText()
                if not raw_email.strip():
                    self.show_error("Please paste email content")
                    return
                email_data = self.parser.parse_raw_email(raw_email)
            else:
                if not hasattr(self, 'file_path') or not self.file_path:
                    self.show_error("Please load a file first")
                    return
                email_data = self.parser.parse_eml_file(self.file_path)
            
            # Show progress
            self.progress_bar.setVisible(True)
            self.progress_bar.setRange(0, 0)  # Indeterminate
            self.analyze_btn.setEnabled(False)
            
            # Start analysis in background thread
            self.analysis_thread = AnalysisThread(email_data)
            self.analysis_thread.finished.connect(self.display_results)
            self.analysis_thread.error.connect(self.show_error)
            self.analysis_thread.start()
            
        except Exception as e:
            self.show_error(f"Error: {str(e)}")
    
    def display_results(self, results):
        """Display analysis results"""
        self.progress_bar.setVisible(False)
        self.analyze_btn.setEnabled(True)
        
        risk = results['risk']
        
        # Update risk display
        score = risk['total_score']
        level = risk['risk_level']
        
        self.risk_display.setText(f"Risk Score: {score}/100 - {level} Risk")
        
        # Color code based on risk
        if level == "Low":
            color = "#4CAF50"
        elif level == "Medium":
            color = "#FF9800"
        else:
            color = "#F44336"
        
        self.risk_display.setStyleSheet(f"""
            background-color: {color};
            color: white;
            border-radius: 8px;
            padding: 15px;
        """)
        
        # Summary tab
        summary = f"""
<h2>Analysis Summary</h2>
<p><strong>Overall Risk:</strong> {level} ({score}/100)</p>

<h3>Score Breakdown</h3>
<ul>
<li>Header Analysis: {risk['breakdown']['header_score']} points</li>
<li>URL Analysis: {risk['breakdown']['url_score']} points</li>
<li>Content Analysis: {risk['breakdown']['content_score']} points</li>
</ul>

<h3>Explanation</h3>
<p>{risk['explanation'].replace(chr(10), '<br>')}</p>
"""
        self.summary_text.setHtml(summary)
        
        # Findings tab
        findings_html = "<h2>Detected Issues</h2>"
        if risk['findings']:
            findings_html += "<ul>"
            for finding in risk['findings']:
                findings_html += f"<li>{finding}</li>"
            findings_html += "</ul>"
        else:
            findings_html += "<p>No significant issues detected.</p>"
        
        self.findings_text.setHtml(findings_html)
        
        # Recommendations tab
        rec_html = "<h2>Security Recommendations</h2><ol>"
        for rec in risk['recommendations']:
            rec_html += f"<li>{rec}</li>"
        rec_html += "</ol>"
        self.recommendations_text.setHtml(rec_html)
        
        # Details tab
        email_info = results['email_info']
        url_info = results['url']
        
        details = f"""
<h2>Email Details</h2>
<p><strong>From:</strong> {email_info.get('from', 'N/A')}</p>
<p><strong>To:</strong> {email_info.get('to', 'N/A')}</p>
<p><strong>Subject:</strong> {email_info.get('subject', 'N/A')}</p>
<p><strong>Date:</strong> {email_info.get('date', 'N/A')}</p>

<h3>URLs Found ({url_info['url_count']})</h3>
"""
        if url_info['urls']:
            details += "<ul>"
            for url in url_info['urls'][:10]:  # Limit to 10
                details += f"<li><code>{url}</code></li>"
            details += "</ul>"
        else:
            details += "<p>No URLs found</p>"
        
        self.details_text.setHtml(details)
    
    def show_error(self, error_msg):
        """Display error message"""
        self.progress_bar.setVisible(False)
        self.analyze_btn.setEnabled(True)
        self.risk_display.setText(f"Error: {error_msg}")
        self.risk_display.setStyleSheet("""
            background-color: #F44336;
            color: white;
            border-radius: 8px;
            padding: 15px;
        """)
