"""
Risk Scorer Module
Aggregates analysis results and generates risk score with explanations
"""

from typing import Dict, List
from ..utils.config import RISK_LOW, RISK_MEDIUM, RISK_HIGH


class RiskScorer:
    """Calculate overall risk score and generate report"""
    
    def __init__(self):
        self.total_score = 0
        self.risk_level = "Low"
        self.all_findings = []
        
    def calculate_risk(self, header_result: Dict, url_result: Dict, 
                       content_result: Dict) -> Dict:
        """
        Calculate overall risk score
        
        Args:
            header_result: Results from header analysis
            url_result: Results from URL analysis
            content_result: Results from content analysis
            
        Returns:
            Dictionary with risk assessment
        """
        # Aggregate scores
        header_score = header_result.get('risk_score', 0)
        url_score = url_result.get('risk_score', 0)
        content_score = content_result.get('risk_score', 0)
        
        self.total_score = min(header_score + url_score + content_score, 100)
        
        # Aggregate findings
        self.all_findings = []
        self.all_findings.extend(header_result.get('findings', []))
        self.all_findings.extend(url_result.get('findings', []))
        self.all_findings.extend(content_result.get('findings', []))
        
        # Determine risk level
        self.risk_level = self._get_risk_level(self.total_score)
        
        # Generate explanation
        explanation = self._generate_explanation(header_score, url_score, content_score)
        
        # Generate recommendations
        recommendations = self._generate_recommendations()
        
        return {
            'total_score': self.total_score,
            'risk_level': self.risk_level,
            'breakdown': {
                'header_score': header_score,
                'url_score': url_score,
                'content_score': content_score,
            },
            'findings': self.all_findings,
            'explanation': explanation,
            'recommendations': recommendations,
        }
    
    def _get_risk_level(self, score: int) -> str:
        """Determine risk level from score"""
        if score <= RISK_LOW:
            return "Low"
        elif score <= RISK_MEDIUM:
            return "Medium"
        else:
            return "High"
    
    def _generate_explanation(self, header_score: int, url_score: int, 
                              content_score: int) -> str:
        """Generate human-readable explanation"""
        explanations = []
        
        if header_score > 10:
            explanations.append(
                f"The email headers show {header_score} points of risk, indicating "
                "potential authentication issues or sender mismatches."
            )
        
        if url_score > 10:
            explanations.append(
                f"URLs in this email contribute {url_score} risk points due to "
                "suspicious domains, link shorteners, or mismatched links."
            )
        
        if content_score > 10:
            explanations.append(
                f"The email content shows {content_score} points of risk from "
                "urgency tactics, threats, or requests for sensitive information."
            )
        
        if self.total_score <= RISK_LOW:
            summary = (
                "This email appears to be legitimate with minimal phishing indicators. "
                "However, always verify unexpected requests independently."
            )
        elif self.total_score <= RISK_MEDIUM:
            summary = (
                "This email shows several suspicious characteristics. "
                "Exercise caution and verify the sender before taking any action."
            )
        else:
            summary = (
                "This email exhibits multiple strong phishing indicators. "
                "DO NOT click links, download attachments, or provide any information. "
                "This is very likely a phishing attempt."
            )
        
        result = summary
        if explanations:
            result += "\n\n" + "\n\n".join(explanations)
        
        return result
    
    def _generate_recommendations(self) -> List[str]:
        """Generate security recommendations based on findings"""
        recommendations = []
        
        # Always include basic recommendations
        recommendations.append(
            "Verify sender identity through a known, trusted channel (not reply email)"
        )
        
        if self.total_score > RISK_LOW:
            recommendations.append(
                "Do not click any links - navigate to websites directly by typing the URL"
            )
            recommendations.append(
                "Never provide passwords, credit card numbers, or sensitive information via email"
            )
        
        if self.total_score > RISK_MEDIUM:
            recommendations.append(
                "Report this email to your IT security team or email provider"
            )
            recommendations.append(
                "Delete this email immediately after reporting"
            )
            recommendations.append(
                "If you clicked any links, change your passwords immediately"
            )
        
        # Add specific recommendations based on findings
        finding_keywords = ' '.join(self.all_findings).lower()
        
        if 'authentication' in finding_keywords or 'spf' in finding_keywords:
            recommendations.append(
                "The sender could not be properly verified - treat with extreme caution"
            )
        
        if 'mismatch' in finding_keywords:
            recommendations.append(
                "Sender information is inconsistent - this is a major red flag"
            )
        
        if 'password' in finding_keywords or 'credential' in finding_keywords:
            recommendations.append(
                "Legitimate companies never ask for passwords via email"
            )
        
        if 'urgent' in finding_keywords or 'threat' in finding_keywords:
            recommendations.append(
                "High-pressure tactics are a common phishing technique - take time to verify"
            )
        
        return recommendations
