"""Core analysis modules"""
