"""
Content Analyzer Module
Analyzes email content for phishing patterns using regex
"""

import re
from typing import Dict, List
from ..utils.config import PHISHING_PATTERNS


class ContentAnalyzer:
    """Analyze email content for phishing indicators"""
    
    def __init__(self):
        self.findings = []
        self.risk_score = 0
        self.pattern_matches = {}
        
    def analyze(self, subject: str, body: str) -> Dict:
        """
        Analyze email content
        
        Args:
            subject: Email subject line
            body: Email body text
            
        Returns:
            Dictionary with content analysis results
        """
        self.findings = []
        self.risk_score = 0
        self.pattern_matches = {
            'urgency': [],
            'financial': [],
            'credentials': [],
            'threats': []
        }
        
        # Combine subject and body for analysis
        full_text = f"{subject}\n{body}"
        
        # Check for urgency patterns
        self._check_patterns(full_text, 'urgency', 5)
        
        # Check for financial keywords
        self._check_patterns(full_text, 'financial', 6)
        
        # Check for credential requests
        self._check_patterns(full_text, 'credentials', 7)
        
        # Check for threatening language
        self._check_patterns(full_text, 'threats', 8)
        
        # Check for generic greetings
        self._check_generic_greeting(body)
        
        # Check for spelling/grammar issues
        self._check_spelling_grammar(full_text)
        
        # Check for excessive urgency
        if len(self.pattern_matches['urgency']) > 2:
            self.findings.append("Multiple urgency indicators detected")
            self.risk_score += 5
        
        return {
            'risk_score': min(self.risk_score, 25),  # Max 25 points from content
            'findings': self.findings,
            'pattern_matches': self.pattern_matches
        }
    
    def _check_patterns(self, text: str, category: str, score_per_match: int):
        """Check for specific pattern category"""
        patterns = PHISHING_PATTERNS.get(category, [])
        
        for pattern in patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            if matches:
                for match in matches[:2]:  # Limit to 2 matches per pattern
                    self.pattern_matches[category].append(match)
                    self.findings.append(
                        f"{category.capitalize()} indicator: '{match}'"
                    )
                self.risk_score += score_per_match
                break  # Only count first matching pattern in category
    
    def _check_generic_greeting(self, body: str):
        """Check for generic greetings (phishing emails often use these)"""
        generic_greetings = [
            r'dear\s+(?:valued\s+)?(?:customer|user|member|client)',
            r'dear\s+sir/madam',
            r'hello\s+(?:dear\s+)?(?:customer|user)',
            r'attention\s+(?:valued\s+)?(?:customer|user)',
        ]
        
        body_lower = body.lower()
        for pattern in generic_greetings:
            if re.search(pattern, body_lower):
                self.findings.append("Uses generic greeting instead of personalized name")
                self.risk_score += 4
                break
    
    def _check_spelling_grammar(self, text: str):
        """Basic check for common spelling/grammar errors"""
        # This is simplified - real implementation would use NLP
        common_errors = [
            (r'\b(\w+)\s+\1\b', 'Repeated word detected'),  # Repeated words
            (r'[.!?]{2,}', 'Excessive punctuation'),
            (r'[A-Z]{5,}', 'Excessive capitalization'),
        ]
        
        error_count = 0
        for pattern, message in common_errors:
            if re.search(pattern, text):
                error_count += 1
        
        if error_count >= 2:
            self.findings.append("Multiple grammar/formatting issues detected")
            self.risk_score += 3
