"""
Email Parser Module
Parses .eml files and raw email text into structured data
"""

import email
from email import policy
from email.parser import Parser
from typing import Dict, Optional, List
import re


class EmailParser:
    """Parse email files and raw text"""
    
    def __init__(self):
        self.parsed_email = None
        self.headers = {}
        self.body = ""
        self.html_body = ""
        
    def parse_eml_file(self, file_path: str) -> Dict:
        """
        Parse an .eml file
        
        Args:
            file_path: Path to .eml file
            
        Returns:
            Dictionary with parsed email data
        """
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                self.parsed_email = email.message_from_file(f, policy=policy.default)
            return self._extract_email_data()
        except Exception as e:
            raise Exception(f"Failed to parse .eml file: {str(e)}")
    
    def parse_raw_email(self, raw_text: str) -> Dict:
        """
        Parse raw email text
        
        Args:
            raw_text: Raw email text/headers
            
        Returns:
            Dictionary with parsed email data
        """
        try:
            parser = Parser(policy=policy.default)
            self.parsed_email = parser.parsestr(raw_text)
            return self._extract_email_data()
        except Exception as e:
            raise Exception(f"Failed to parse raw email: {str(e)}")
    
    def _extract_email_data(self) -> Dict:
        """Extract relevant data from parsed email"""
        if not self.parsed_email:
            return {}
        
        # Extract headers
        self.headers = {
            'from': self.parsed_email.get('From', ''),
            'to': self.parsed_email.get('To', ''),
            'subject': self.parsed_email.get('Subject', ''),
            'date': self.parsed_email.get('Date', ''),
            'return_path': self.parsed_email.get('Return-Path', ''),
            'received': self.parsed_email.get_all('Received', []),
            'message_id': self.parsed_email.get('Message-ID', ''),
            'reply_to': self.parsed_email.get('Reply-To', ''),
            'authentication_results': self.parsed_email.get('Authentication-Results', ''),
            'received_spf': self.parsed_email.get('Received-SPF', ''),
            'dkim_signature': self.parsed_email.get('DKIM-Signature', ''),
        }
        
        # Extract body
        self.body = self._get_email_body()
        self.html_body = self._get_html_body()
        
        return {
            'headers': self.headers,
            'body': self.body,
            'html_body': self.html_body,
            'raw_email': self.parsed_email
        }
    
    def _get_email_body(self) -> str:
        """Extract plain text body from email"""
        body = ""
        
        if self.parsed_email.is_multipart():
            for part in self.parsed_email.walk():
                content_type = part.get_content_type()
                if content_type == 'text/plain':
                    try:
                        body += part.get_payload(decode=True).decode('utf-8', errors='ignore')
                    except:
                        pass
        else:
            try:
                body = self.parsed_email.get_payload(decode=True).decode('utf-8', errors='ignore')
            except:
                body = str(self.parsed_email.get_payload())
        
        return body
    
    def _get_html_body(self) -> str:
        """Extract HTML body from email"""
        html = ""
        
        if self.parsed_email.is_multipart():
            for part in self.parsed_email.walk():
                content_type = part.get_content_type()
                if content_type == 'text/html':
                    try:
                        html += part.get_payload(decode=True).decode('utf-8', errors='ignore')
                    except:
                        pass
        
        return html
    
    def get_from_email(self) -> str:
        """Extract email address from From header"""
        from_header = self.headers.get('from', '')
        # Extract email from "Name <email@example.com>" format
        match = re.search(r'<(.+?)>', from_header)
        if match:
            return match.group(1)
        return from_header
    
    def get_from_name(self) -> str:
        """Extract display name from From header"""
        from_header = self.headers.get('from', '')
        # Extract name from "Name <email@example.com>" format
        match = re.search(r'^(.+?)\s*<', from_header)
        if match:
            return match.group(1).strip('"').strip("'")
        return ""
