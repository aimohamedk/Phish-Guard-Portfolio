"""
URL Extractor Module
Extracts and analyzes URLs from email content
"""

import re
from typing import List, Dict
from urllib.parse import urlparse
from ..utils.config import SUSPICIOUS_TLDS, URL_SHORTENERS, IP_PATTERN


class URLExtractor:
    """Extract and analyze URLs from email body"""
    
    def __init__(self):
        self.urls = []
        self.findings = []
        self.risk_score = 0
        
    def analyze(self, body: str, html_body: str = "") -> Dict:
        """
        Extract and analyze URLs
        
        Args:
            body: Plain text email body
            html_body: HTML email body
            
        Returns:
            Dictionary with URL analysis results
        """
        self.urls = []
        self.findings = []
        self.risk_score = 0
        
        # Extract URLs from plain text
        text_urls = self._extract_urls_from_text(body)
        
        # Extract URLs from HTML (href attributes)
        html_urls = self._extract_urls_from_html(html_body) if html_body else []
        
        # Combine and deduplicate
        all_urls = list(set(text_urls + html_urls))
        self.urls = all_urls
        
        # Analyze each URL
        for url in all_urls:
            self._analyze_url(url)
        
        # Check for URL/display text mismatch in HTML
        if html_body:
            self._check_url_mismatch(html_body)
        
        return {
            'risk_score': min(self.risk_score, 30),  # Max 30 points from URLs
            'findings': self.findings,
            'urls': self.urls,
            'url_count': len(self.urls)
        }
    
    def _extract_urls_from_text(self, text: str) -> List[str]:
        """Extract URLs from plain text"""
        # Pattern to match URLs
        url_pattern = r'https?://[^\s<>"]+|www\.[^\s<>"]+'
        urls = re.findall(url_pattern, text, re.IGNORECASE)
        
        # Clean up URLs (remove trailing punctuation)
        cleaned_urls = []
        for url in urls:
            url = re.sub(r'[.,;:!?)]+$', '', url)
            if url.startswith('www.'):
                url = 'http://' + url
            cleaned_urls.append(url)
        
        return cleaned_urls
    
    def _extract_urls_from_html(self, html: str) -> List[str]:
        """Extract URLs from HTML href attributes"""
        # Pattern to match href attributes
        href_pattern = r'href=["\']([^"\']+)["\']'
        urls = re.findall(href_pattern, html, re.IGNORECASE)
        
        # Filter out non-http URLs (like mailto:, #anchors)
        http_urls = [url for url in urls if url.startswith(('http://', 'https://'))]
        
        return http_urls
    
    def _analyze_url(self, url: str):
        """Analyze individual URL for phishing indicators"""
        try:
            parsed = urlparse(url)
            domain = parsed.netloc.lower()
            
            # Check for IP address instead of domain
            if re.match(IP_PATTERN, domain):
                self.findings.append(f"URL uses IP address instead of domain: {url}")
                self.risk_score += 10
            
            # Check for suspicious TLDs
            for tld in SUSPICIOUS_TLDS:
                if domain.endswith(tld):
                    self.findings.append(f"URL uses suspicious TLD ({tld}): {url}")
                    self.risk_score += 8
                    break
            
            # Check for URL shorteners
            for shortener in URL_SHORTENERS:
                if shortener in domain:
                    self.findings.append(f"URL uses link shortener: {url}")
                    self.risk_score += 5
                    break
            
            # Check for typosquatting patterns
            self._check_typosquatting(domain, url)
            
            # Check for excessive subdomains
            subdomain_count = domain.count('.')
            if subdomain_count > 3:
                self.findings.append(f"URL has unusual number of subdomains: {url}")
                self.risk_score += 5
            
            # Check for suspicious keywords in domain
            suspicious_keywords = ['secure', 'account', 'verify', 'login', 'update', 
                                   'confirm', 'banking', 'paypal', 'amazon']
            domain_lower = domain.lower()
            for keyword in suspicious_keywords:
                if keyword in domain_lower:
                    self.findings.append(f"URL contains suspicious keyword '{keyword}': {url}")
                    self.risk_score += 3
                    break
            
            # Check for @ symbol in URL (tricks browser)
            if '@' in url:
                self.findings.append(f"URL contains @ symbol (browser redirection trick): {url}")
                self.risk_score += 15
            
        except Exception as e:
            self.findings.append(f"Could not parse URL: {url}")
    
    def _check_typosquatting(self, domain: str, url: str):
        """Check for common typosquatting patterns"""
        # Common brands to check
        legitimate_domains = [
            'paypal.com', 'amazon.com', 'microsoft.com', 'apple.com',
            'google.com', 'facebook.com', 'bankofamerica.com', 'chase.com',
            'wellsfargo.com', 'citibank.com', 'usbank.com', 'irs.gov'
        ]
        
        for legit in legitimate_domains:
            # Check for similar but not exact domain
            if self._is_similar(domain, legit) and domain != legit:
                self.findings.append(
                    f"Possible typosquatting of '{legit}': {url}"
                )
                self.risk_score += 12
                break
    
    def _is_similar(self, domain: str, target: str) -> bool:
        """Check if domain is similar to target (basic check)"""
        # Remove TLD for comparison
        domain_base = domain.rsplit('.', 1)[0] if '.' in domain else domain
        target_base = target.rsplit('.', 1)[0] if '.' in target else target
        
        # Check if target appears in domain with modifications
        if target_base in domain_base:
            return True
        
        # Check for common character substitutions
        substitutions = {
            'o': '0', '0': 'o',
            'i': 'l', 'l': 'i', '1': 'l',
            'a': '@',
        }
        
        # Simple Levenshtein-like check (1-2 character difference)
        if abs(len(domain_base) - len(target_base)) <= 2:
            # Count differences
            min_len = min(len(domain_base), len(target_base))
            differences = sum(1 for i in range(min_len) if domain_base[i] != target_base[i])
            if differences <= 2:
                return True
        
        return False
    
    def _check_url_mismatch(self, html: str):
        """Check if displayed text differs from actual link (HTML only)"""
        # Pattern to match <a href="URL">text</a>
        link_pattern = r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>([^<]+)</a>'
        matches = re.findall(link_pattern, html, re.IGNORECASE | re.DOTALL)
        
        for href, text in matches:
            # Check if text looks like a URL but differs from href
            if 'http' in text.lower() or 'www.' in text.lower():
                # Extract domain from href
                try:
                    href_parsed = urlparse(href)
                    href_domain = href_parsed.netloc
                    
                    # Check if text contains different domain
                    if href_domain not in text and not text.startswith('http'):
                        continue
                    
                    # Simple check: if text is URL-like and doesn't match href
                    if href not in text and text.lower() not in href.lower():
                        self.findings.append(
                            f"Link text mismatch: displays '{text[:50]}' but links to '{href}'"
                        )
                        self.risk_score += 10
                except:
                    pass
