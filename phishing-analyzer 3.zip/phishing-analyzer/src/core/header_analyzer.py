"""
Header Analyzer Module
Analyzes email headers for phishing indicators
"""

import re
from typing import Dict, List, Tuple
from ..utils.config import FREE_EMAIL_PROVIDERS


class HeaderAnalyzer:
    """Analyze email headers for suspicious patterns"""
    
    def __init__(self):
        self.findings = []
        self.risk_score = 0
        
    def analyze(self, headers: Dict, from_email: str, from_name: str) -> Dict:
        """
        Analyze email headers
        
        Args:
            headers: Dictionary of email headers
            from_email: Extracted sender email
            from_name: Extracted sender name
            
        Returns:
            Dictionary with analysis results
        """
        self.findings = []
        self.risk_score = 0
        
        # Check for mismatched sender
        self._check_sender_mismatch(from_email, from_name)
        
        # Check authentication
        self._check_authentication(headers)
        
        # Check return path
        self._check_return_path(headers, from_email)
        
        # Check reply-to
        self._check_reply_to(headers, from_email)
        
        # Check received headers (routing)
        self._check_received_headers(headers)
        
        # Check for free email provider
        self._check_free_email(from_email)
        
        return {
            'risk_score': min(self.risk_score, 25),  # Max 25 points from headers
            'findings': self.findings,
            'details': {
                'from_email': from_email,
                'from_name': from_name,
                'spf': self._extract_spf_result(headers),
                'dkim': self._extract_dkim_result(headers),
            }
        }
    
    def _check_sender_mismatch(self, from_email: str, from_name: str):
        """Check if sender name doesn't match email domain"""
        if not from_name or not from_email:
            return
        
        # Extract domain from email
        domain_match = re.search(r'@(.+)$', from_email)
        if not domain_match:
            return
        
        domain = domain_match.group(1).lower()
        name_lower = from_name.lower()
        
        # Check if display name mentions a different company/domain
        # Common phishing: "PayPal Support <scammer@gmail.com>"
        suspicious_keywords = ['paypal', 'amazon', 'microsoft', 'apple', 'google', 
                               'bank', 'irs', 'fedex', 'ups', 'dhl']
        
        for keyword in suspicious_keywords:
            if keyword in name_lower and keyword not in domain:
                self.findings.append(
                    f"Sender name mentions '{keyword}' but email is from '{domain}'"
                )
                self.risk_score += 10
                break
    
    def _check_authentication(self, headers: Dict):
        """Check SPF and DKIM authentication"""
        spf = self._extract_spf_result(headers)
        dkim = self._extract_dkim_result(headers)
        
        if not spf or spf.lower() not in ['pass', 'neutral']:
            self.findings.append("Missing or failed SPF authentication")
            self.risk_score += 5
        
        if not dkim or 'pass' not in dkim.lower():
            self.findings.append("Missing or failed DKIM signature")
            self.risk_score += 3
    
    def _extract_spf_result(self, headers: Dict) -> str:
        """Extract SPF result from headers"""
        spf = headers.get('received_spf', '')
        auth = headers.get('authentication_results', '')
        
        if spf:
            match = re.search(r'(pass|fail|softfail|neutral|none)', spf, re.I)
            if match:
                return match.group(1)
        
        if auth and 'spf=' in auth.lower():
            match = re.search(r'spf=(\w+)', auth, re.I)
            if match:
                return match.group(1)
        
        return ""
    
    def _extract_dkim_result(self, headers: Dict) -> str:
        """Extract DKIM result from headers"""
        dkim = headers.get('dkim_signature', '')
        auth = headers.get('authentication_results', '')
        
        if dkim:
            return "present"
        
        if auth and 'dkim=' in auth.lower():
            match = re.search(r'dkim=(\w+)', auth, re.I)
            if match:
                return match.group(1)
        
        return ""
    
    def _check_return_path(self, headers: Dict, from_email: str):
        """Check if return path matches sender email"""
        return_path = headers.get('return_path', '')
        
        if return_path:
            # Extract email from return path
            rp_email = re.search(r'<(.+?)>', return_path)
            if rp_email:
                rp_email = rp_email.group(1)
            else:
                rp_email = return_path
            
            # Check if domains match
            from_domain = re.search(r'@(.+)$', from_email)
            rp_domain = re.search(r'@(.+)$', rp_email)
            
            if from_domain and rp_domain:
                if from_domain.group(1) != rp_domain.group(1):
                    self.findings.append(
                        f"Return-Path domain ({rp_domain.group(1)}) differs from sender domain"
                    )
                    self.risk_score += 7
    
    def _check_reply_to(self, headers: Dict, from_email: str):
        """Check if reply-to differs from sender"""
        reply_to = headers.get('reply_to', '')
        
        if reply_to and reply_to != from_email:
            # Extract email from reply-to
            rt_email = re.search(r'<(.+?)>', reply_to)
            if rt_email:
                rt_email = rt_email.group(1)
            else:
                rt_email = reply_to
            
            if rt_email.lower() != from_email.lower():
                self.findings.append(
                    f"Reply-To address ({rt_email}) differs from sender"
                )
                self.risk_score += 5
    
    def _check_received_headers(self, headers: Dict):
        """Check email routing for suspicious patterns"""
        received = headers.get('received', [])
        
        if isinstance(received, str):
            received = [received]
        
        if len(received) > 10:
            self.findings.append(
                f"Unusual number of hops ({len(received)}) - possible email forwarding chain"
            )
            self.risk_score += 3
        
        # Check for suspicious countries/IPs in routing
        # This is simplified - in production you'd use GeoIP lookup
        suspicious_patterns = ['.ru', '.cn', '.tk', 'anonymous']
        
        for rec in received:
            rec_lower = rec.lower()
            for pattern in suspicious_patterns:
                if pattern in rec_lower:
                    self.findings.append(
                        f"Email routed through potentially suspicious location"
                    )
                    self.risk_score += 5
                    break
    
    def _check_free_email(self, from_email: str):
        """Check if sender uses free email provider (unusual for businesses)"""
        domain_match = re.search(r'@(.+)$', from_email)
        if domain_match:
            domain = domain_match.group(1).lower()
            if domain in FREE_EMAIL_PROVIDERS:
                # Only flag if claiming to be from a company
                # This is a weak signal, so low score
                self.findings.append(
                    f"Sent from free email provider ({domain})"
                )
                self.risk_score += 2
