# 📥 Installation & Testing Guide

## 🎯 For Recruiters & Testers

This guide will help you quickly set up and test the Phishing Analyzer.

---

## Option 1: Quick Test (Recommended for Recruiters)

### Download & Extract
1. Download `phishing-analyzer.zip`
2. Extract to any location (e.g., `C:\Projects\phishing-analyzer`)
3. Open folder in VSCode or your preferred IDE

### Install Dependencies
```bash
# Open terminal in the project folder
pip install -r requirements.txt
```

This installs:
- PySide6 (GUI framework)
- PyInstaller (for building .exe)

### Run the Application
```bash
python main.py
```

### Test with Sample Phishing Email
1. Click **"Load .EML File"**
2. Navigate to `sample_emails/sample_phishing.eml`
3. Click **"Analyze Email"**
4. **Expected Result**: Risk Score 70-90+ (High Risk)

**Key Findings You'll See**:
- ✗ Sender name "PayPal" but email from `.xyz` domain
- ✗ URL uses IP address (192.168.1.100)
- ✗ Suspicious TLD (.xyz, .top)
- ✗ Multiple urgency indicators
- ✗ Requests for credentials and SSN
- ✗ Threatening language

### Test with Legitimate Email
1. Click **"Clear"**
2. Load `sample_emails/sample_legitimate.eml`
3. Click **"Analyze Email"**
4. **Expected Result**: Risk Score 0-20 (Low Risk)

**Key Indicators**:
- ✓ Valid SPF/DKIM authentication
- ✓ Legitimate GitHub domain
- ✓ No suspicious URLs
- ✓ No urgency or threats

---

## Option 2: Build Executable (.exe)

### Using Build Script (Easy)
```bash
python build.py
```

### Manual Build (Advanced)
```bash
pyinstaller --onefile --windowed --name PhishingAnalyzer main.py
```

### Result
- Executable: `dist/PhishingAnalyzer.exe`
- Size: ~50MB (includes Python runtime)
- **No Python needed** on target machine

### Test Executable
```bash
dist\PhishingAnalyzer.exe
```

---

## 🧪 Advanced Testing Scenarios

### Test 1: URL Typosquatting Detection
**Paste this email**:
```
From: Apple Support <support@app1e.com>
Subject: Your Apple ID has been compromised

Click here to secure your account: http://appleid-verify.xyz
```

**Expected**: High risk due to typosquatting (app1e instead of apple)

### Test 2: IP Address URL
**Paste this**:
```
From: Security Team <alert@company.com>
Subject: Security Alert

Verify here: http://192.168.1.100/verify
```

**Expected**: Medium-High risk due to IP address instead of domain

### Test 3: Link Shortener
**Paste this**:
```
From: HR Department <hr@company.com>
Subject: Important Update

Check this: https://bit.ly/abc123
```

**Expected**: Low-Medium risk (link shortener is suspicious but sender looks OK)

### Test 4: Legitimate Email
**Paste this**:
```
From: Team Lead <john@yourcompany.com>
To: you@yourcompany.com
Subject: Meeting tomorrow
Authentication-Results: spf=pass; dkim=pass

Hi,

Let's meet tomorrow at 2 PM to discuss the project.

Best,
John
```

**Expected**: Very low risk

---

## 📊 Understanding the Results

### Risk Score Breakdown

**Display Format**: `Risk Score: XX/100 - [Level] Risk`

| Score | Level | Color | Meaning |
|-------|-------|-------|---------|
| 0-30 | Low | Green | Minimal indicators, likely safe |
| 31-60 | Medium | Orange | Several red flags, verify sender |
| 61-100 | High | Red | Strong phishing indicators, DO NOT TRUST |

### Analysis Tabs

**📊 Summary Tab**:
- Overall risk assessment
- Score breakdown by category
- Human-readable explanation

**🔍 Findings Tab**:
- Detailed list of suspicious indicators
- Specific issues detected

**💡 Recommendations Tab**:
- Security best practices
- Actions to take based on risk level

**📧 Email Details Tab**:
- Sender, recipient, subject
- URLs found in email
- Basic metadata

---

## 🎥 Usage Walkthrough

### Loading a File
1. **Click** "📁 Load .EML File"
2. **Select** any .eml file from your system
3. **Status** changes to "Loaded: [filename]"
4. **Button** "🔍 Analyze Email" becomes enabled
5. **Click** to analyze

### Paste Mode
1. **Click** "📋 Paste Raw Email"
2. **Text box** appears
3. **Paste** raw email (with headers)
4. **Click** "🔍 Analyze Email"

**Where to get raw email**:
- Gmail: Three dots → Show original
- Outlook: File → Properties → Internet Headers
- Thunderbird: Ctrl+U or View → Message Source

### Clearing Results
- **Click** "🗑️ Clear" to reset everything
- Start fresh with a new email

---

## 🔧 Troubleshooting

### Problem: "ModuleNotFoundError: PySide6"
**Solution**:
```bash
pip install PySide6
```

### Problem: "No module named 'src'"
**Solution**:
```bash
# Make sure you're in the project root directory
cd phishing-analyzer
python main.py
```

### Problem: Application won't start
**Solution**:
```bash
# Check Python version (need 3.8+)
python --version

# Reinstall dependencies
pip install --force-reinstall -r requirements.txt
```

### Problem: PyInstaller build fails
**Solution**:
```bash
# Update PyInstaller
pip install --upgrade pyinstaller

# Try manual build
pyinstaller --onefile --windowed main.py
```

### Problem: Executable is too large
**Explanation**: The .exe includes entire Python runtime (~50MB). This is normal for PyInstaller applications.

---

## 📁 Project Files Overview

### Essential Files to Review

| File | Purpose | Lines of Code |
|------|---------|---------------|
| `main.py` | Application entry point | ~20 |
| `src/core/email_parser.py` | Email parsing logic | ~150 |
| `src/core/header_analyzer.py` | Authentication checks | ~200 |
| `src/core/url_extractor.py` | URL threat detection | ~250 |
| `src/core/content_analyzer.py` | Pattern matching | ~100 |
| `src/core/risk_scorer.py` | Risk calculation | ~150 |
| `src/ui/main_window.py` | GUI implementation | ~400 |
| `src/utils/config.py` | Configuration | ~100 |

**Total**: ~1,370 lines of production code

---

## 💼 For Code Review

### Architecture Highlights
- ✅ **Modular design**: Each analyzer is independent
- ✅ **Clean interfaces**: Dict-based communication
- ✅ **Type safety**: Type hints throughout
- ✅ **Error handling**: Try-except blocks
- ✅ **Threading**: Non-blocking UI
- ✅ **Configuration**: Centralized in config.py

### Code Quality Checkers
```bash
# Check code style (if you have flake8)
flake8 src/

# Count lines of code
find src -name "*.py" -exec wc -l {} + | tail -1
```

### Suggested Improvements (Future)
- [ ] Add unit tests
- [ ] Implement ML-based classification
- [ ] Add VirusTotal API integration
- [ ] Support for multiple languages
- [ ] Attachment scanning
- [ ] Database of known campaigns

---

## 🎓 Educational Value

### What This Project Demonstrates

**Cybersecurity Skills**:
- Email protocol understanding (SMTP, headers, MIME)
- Authentication mechanisms (SPF, DKIM)
- Phishing techniques and detection
- Threat analysis methodologies
- Security risk scoring

**Software Engineering**:
- Python OOP and modular design
- Desktop GUI development (Qt/PySide6)
- Regular expression expertise
- Multi-threading
- Application packaging and distribution

**Professional Skills**:
- Clean, documented code
- User-friendly interface design
- Comprehensive documentation
- Project organization
- Build and deployment processes

---

## 📞 Next Steps

1. ✅ Test both sample emails
2. ✅ Try paste mode with real emails
3. ✅ Review source code in VSCode
4. ✅ Build the executable
5. ✅ Test the standalone .exe
6. ⭐ Add to your portfolio/GitHub

---

**Questions or Issues?** Check README.md for full documentation or review the inline code comments.

**Impressed?** This tool took careful design and implementation to balance security analysis with usability and clean code architecture.
