# 🚀 Quick Start Guide

## Getting Started in 3 Steps

### Step 1: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 2: Run the Application
```bash
python main.py
```

### Step 3: Test with Sample Email
1. Click "Load .EML File"
2. Navigate to `sample_emails/` folder
3. Open `sample_phishing.eml`
4. Click "Analyze Email"

## Building Executable (.exe)

### Option 1: Using Build Script (Recommended)
```bash
python build.py
```

### Option 2: Manual PyInstaller Command
```bash
pyinstaller --onefile --windowed --name PhishingAnalyzer main.py
```

The executable will be in `dist/PhishingAnalyzer.exe`

## Testing Guide

### Test Case 1: Phishing Email (High Risk)
- Load: `sample_emails/sample_phishing.eml`
- Expected: Risk Score 70-90+
- Indicators: IP address URL, suspicious TLD, urgency, credential request

### Test Case 2: Legitimate Email (Low Risk)
- Load: `sample_emails/sample_legitimate.eml`
- Expected: Risk Score 0-20
- Indicators: Valid auth, legitimate domain, no threats

### Test Case 3: Paste Mode
1. Click "Paste Raw Email"
2. Copy any email from your email client (View Source/Raw)
3. Paste into text box
4. Click "Analyze Email"

## Troubleshooting

### "No module named PySide6"
```bash
pip install PySide6
```

### "ModuleNotFoundError: src.core"
- Make sure you run `python main.py` from the project root directory
- Or use: `cd phishing-analyzer && python main.py`

### Executable build fails
```bash
pip install --upgrade pyinstaller
python build.py
```

## For Recruiters / Reviewers

This project demonstrates:

✅ **Modular Architecture**: Clean separation of concerns  
✅ **Security Knowledge**: Understanding of email authentication, phishing techniques  
✅ **GUI Development**: Professional desktop application with PySide6  
✅ **Pattern Matching**: Sophisticated regex-based detection  
✅ **Risk Assessment**: Weighted scoring system with explanations  
✅ **Code Quality**: Well-documented, maintainable code  

### Key Files to Review:
- `src/core/header_analyzer.py` - Email authentication analysis
- `src/core/url_extractor.py` - URL threat detection  
- `src/core/risk_scorer.py` - Risk calculation logic
- `src/ui/main_window.py` - Professional UI implementation

## Next Steps

1. ⭐ Test with real phishing emails (be careful!)
2. 📦 Build executable for distribution
3. 📝 Customize patterns in `src/utils/config.py`
4. 🚀 Add to your GitHub portfolio
5. 💼 Showcase in job applications

---

**Need Help?** Check README.md for full documentation.
